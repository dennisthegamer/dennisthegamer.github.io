package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudAnchor;
import net.minecraft.class_332;

/** Der konsumierende Mod liefert Größe, Scale und Sample-Zeichnung seiner eigenen HUD-Box. */
public interface HudBoxProvider {
    int width();
    int height();

    /** Konsumenten-HUD-Scale (z.B. hudScale); 1.0f, falls der Mod keine eigene Skalierung hat. */
    float scale();

    /** Zeichnet die Beispiel-Box; der Konsument handhabt sein eigenes Scale-Push/Pop. */
    void drawSample(class_332 graphics, int x, int y, float scale);

    /**
     * Wie {@link #drawSample(class_332, int, int, float)}, kennt aber den Anker,
     * an dem gerade gezeichnet wird. Inhalte, deren Ausrichtung vom Anker abhängt
     * (Textlisten), überschreiben diese Methode; für feste Boxen ist sie bedeutungslos.
     */
    default void drawSample(class_332 graphics, int x, int y, float scale, HudAnchor anchor) {
        drawSample(graphics, x, y, scale);
    }
}
