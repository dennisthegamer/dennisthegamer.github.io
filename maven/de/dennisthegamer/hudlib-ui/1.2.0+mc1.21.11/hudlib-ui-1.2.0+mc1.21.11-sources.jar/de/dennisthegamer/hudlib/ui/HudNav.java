package de.dennisthegamer.hudlib.ui;

import net.minecraft.class_310;
import net.minecraft.class_437;

/**
 * Einziger Ort für den Screen-Wechsel. Auf der 26.x-Linie wandert Minecraft.setScreen ab 26.2
 * nach Gui.setScreen; auf dieser 1.21.x-Linie gibt es diesen Sprung nicht -- Minecraft.setScreen
 * existiert von 1.21 bis 1.21.11 durchgehend, also braucht es hier keine Fallunterscheidung.
 */
final class HudNav {

    private HudNav() {
    }

    static void setScreen(class_437 screen) {
        class_310.method_1551().method_1507(screen);
    }
}
