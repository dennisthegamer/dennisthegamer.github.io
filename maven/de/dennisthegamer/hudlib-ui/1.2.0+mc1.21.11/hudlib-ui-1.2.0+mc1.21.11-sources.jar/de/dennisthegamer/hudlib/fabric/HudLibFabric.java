package de.dennisthegamer.hudlib.fabric;

import de.dennisthegamer.hudlib.ui.HudRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2960;

/**
 * Fabric-Seite der HUD-Registrierung; aus dem ClientModInitializer des Konsumenten aufrufen.
 *
 * <p>Anders als auf 26.x läuft das hier über HudRenderCallback statt über
 * HudElementRegistry: die Element-API taucht in der Fabric-API erst zwischen 1.21.5 und
 * 1.21.8 auf, Band A (mc1.21-1.21.5) wird aber gegen 1.21.5 kompiliert und könnte sie
 * deshalb nicht referenzieren. Band B (mc1.21.6-1.21.8, kompiliert gegen 1.21.8) hätte
 * HudElementRegistry durchaus zur Verfügung — die einheitliche Wahl über alle vier Bänder
 * ist hier also Konsistenz, kein Zwang auf jedem Band: ein Codepfad statt eines
 * Versionsblocks, der auf drei von vier Bändern die Bossbar-Platzierung zurückbrächte.
 * HudRenderCallback gibt es über die gesamte Spanne mit identischer Signatur.</p>
 *
 * <p>Folge: {@code id} wird auf dieser Linie nicht ausgewertet — HudRenderCallback kennt
 * keine benannten Elemente und zeichnet nach dem gesamten HUD statt hinter der Bossbar.
 * Der Parameter bleibt trotzdem stehen, damit die Aufrufstelle über beide MC-Linien
 * gleich aussieht.</p>
 *
 * <p>HudRenderCallback ist auf allen vier Bändern deprecated (javac warnt bei jedem
 * compileFabricJava). Bewusst in Kauf genommen aus demselben Konsistenzgrund oben — nicht
 * versionsgeblockt auf HudElementRegistry umstellen: das wäre eine
 * Laufzeitverhaltensänderung (andere Render-Position), die ohne Spielstart nicht
 * verifizierbar ist, und ist für dieses Release bewusst ausgeschlossen.</p>
 */
public final class HudLibFabric {

    private HudLibFabric() {
    }

    /** Hängt das HUD-Element hinter das vanilla HUD (Standard-Slot der HudLib-Mods). */
    //? if >=1.21.11 {
    public static void register(class_2960 id, HudRenderer renderer) {
    //?} else {
    /*public static void register(ResourceLocation id, HudRenderer renderer) {
    *///?}
        HudRenderCallback.EVENT.register(renderer::render);
    }
}
