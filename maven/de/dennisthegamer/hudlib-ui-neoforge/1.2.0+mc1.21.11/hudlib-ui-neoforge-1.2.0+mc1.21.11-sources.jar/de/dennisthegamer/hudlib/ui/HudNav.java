package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/**
 * Einziger Ort für den Screen-Wechsel. Auf der 26.x-Linie wandert Minecraft.setScreen ab 26.2
 * nach Gui.setScreen; auf dieser 1.21.x-Linie gibt es diesen Sprung nicht -- Minecraft.setScreen
 * existiert von 1.21 bis 1.21.11 durchgehend, also braucht es hier keine Fallunterscheidung.
 */
final class HudNav {

    private HudNav() {
    }

    static void setScreen(Screen screen) {
        Minecraft.getInstance().setScreen(screen);
    }
}
