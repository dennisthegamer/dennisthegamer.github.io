package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudPlacement;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2fStack;

/**
 * Zeichnet eine HUD-Box an ihrem {@link HudPlacement}: skaliert (pose push/scale), malt den
 * Opacity-Hintergrund und ruft den Content-Zeichner mit dem Box-Ursprung auf. Ersetzt das in
 * den Konsumenten kopierte Ecken-/Margin-/Scale-Boilerplate; da das Placement durchgereicht
 * wird, ist jedes HudPanel-HUD automatisch frei positionierbar.
 */
public final class HudPanel {

    private HudPanel() {
    }

    @FunctionalInterface
    public interface HudContent {
        /** Zeichnet den Box-Inhalt; (x,y) ist die linke obere Box-Ecke im skalierten Raum. */
        void draw(GuiGraphicsExtractor graphics, int x, int y);
    }

    /** Löst das Placement im skalierten Bildschirmraum auf und zeichnet dort. */
    public static void draw(GuiGraphicsExtractor graphics, HudPlacement placement,
                            int boxWidth, int boxHeight, float scale, float bgOpacity,
                            HudContent content) {
        float s = scale <= 0 ? 1.0f : scale;
        int scaledW = (int) (graphics.guiWidth() / s);
        int scaledH = (int) (graphics.guiHeight() / s);
        int x = placement.resolveX(scaledW, boxWidth);
        int y = placement.resolveY(scaledH, boxHeight);
        drawAt(graphics, x, y, boxWidth, boxHeight, s, bgOpacity, content);
    }

    /** Zeichnet die Box an expliziten (skalierten) Koordinaten — für Editor-Vorschauen. */
    public static void drawAt(GuiGraphicsExtractor graphics, int x, int y,
                              int boxWidth, int boxHeight, float scale, float bgOpacity,
                              HudContent content) {
        float s = scale <= 0 ? 1.0f : scale;
        Matrix3x2fStack pose = graphics.pose();
        pose.pushMatrix();
        pose.scale(s, s);
        if (bgOpacity > 0) {
            int bgColor = (int) (bgOpacity * 255) << 24;
            graphics.fill(x, y, x + boxWidth, y + boxHeight, bgColor);
        }
        content.draw(graphics, x, y);
        pose.popMatrix();
    }
}
