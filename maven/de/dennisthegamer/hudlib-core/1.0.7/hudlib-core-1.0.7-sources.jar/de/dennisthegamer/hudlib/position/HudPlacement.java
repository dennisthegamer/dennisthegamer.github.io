package de.dennisthegamer.hudlib.position;

/**
 * Frei gewählte HUD-Position als Anker + Pixel-Offset. Auflösungs-/Scale-robust:
 * {@link #resolveX}/{@link #resolveY} klemmen so, dass die Box nie aus dem Bild ragt.
 * Reine Mathematik, keine Minecraft-Abhängigkeit.
 */
public record HudPlacement(HudAnchor anchor, int offsetX, int offsetY) {

    /**
     * Abstand, den {@link #of(HudAnchor)} zwischen Box und Bildschirmrand lässt. Entspricht dem
     * {@code MARGIN} der alten HUD-Renderer und damit dem, was migrierte Nutzer gewohnt sind.
     */
    public static final int DEFAULT_MARGIN = 10;

    /**
     * Standard-Placement für einen Anker: randnahe Anker rücken um {@link #DEFAULT_MARGIN} nach
     * innen. Ohne diesen Rand klebte die Box bündig am Bildschirmrand und der Editor-Rahmen, der
     * 1px ausserhalb der Box liegt, wurde abgeschnitten.
     */
    public static HudPlacement of(HudAnchor anchor) {
        return of(anchor, DEFAULT_MARGIN);
    }

    /** Wie {@link #of(HudAnchor)}, mit eigenem Randabstand. */
    public static HudPlacement of(HudAnchor anchor, int margin) {
        return new HudPlacement(anchor, anchor.marginX(margin), anchor.marginY(margin));
    }

    /**
     * Erzeugt ein Placement, das (im ungeklemmten Fall) die Box genau an (absX,absY) legt,
     * indem der Offset relativ zur Anker-Basis berechnet wird.
     */
    public static HudPlacement fromAbsolute(HudAnchor anchor, int absX, int absY,
                                            int screenW, int screenH, int boxW, int boxH) {
        return new HudPlacement(anchor,
                absX - anchor.baseX(screenW, boxW),
                absY - anchor.baseY(screenH, boxH));
    }

    public int resolveX(int screenW, int boxW) {
        return clamp(anchor.baseX(screenW, boxW) + offsetX, 0, Math.max(0, screenW - boxW));
    }

    public int resolveY(int screenH, int boxH) {
        return clamp(anchor.baseY(screenH, boxH) + offsetY, 0, Math.max(0, screenH - boxH));
    }

    private static int clamp(int value, int lo, int hi) {
        if (value < lo) return lo;
        return Math.min(value, hi);
    }
}
