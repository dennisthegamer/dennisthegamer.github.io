package de.dennisthegamer.hudlib.neoforge;

import de.dennisthegamer.hudlib.ui.HudRenderer;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
//? if >=1.21.11 {
/*import net.minecraft.resources.Identifier;
*///?} else {
import net.minecraft.resources.ResourceLocation;
//?}

/**
 * NeoForge-Seite der HUD-Registrierung; aus dem RegisterGuiLayersEvent-Handler des
 * Konsumenten-Mod-Busses aufrufen (Gui-Layer sind pro Mod-Bus — deshalb reicht der
 * Konsument das Event herein, statt dass die Lib selbst lauscht).
 *
 * <p>registerAbove nimmt bis 1.21.5 ein LayeredDraw.Layer und ab 1.21.6 ein GuiLayer (per
 * javap: 21.5.97 vs. 21.6.20-beta/21.7.25-beta/21.8.53/21.10.64/21.11.42). Das fällt mit
 * dem Band-A/B-Schnitt zusammen, betrifft also kein Band intern — und beide SAMs
 * deklarieren ohnehin render(GuiGraphics, DeltaTracker), deshalb passt dieselbe
 * Methodenreferenz auf beide und nur der Id-Typ braucht einen Versionsblock (Grenze
 * 1.21.11, siehe unten).</p>
 */
public final class HudLibNeoForge {

    private HudLibNeoForge() {
    }

    /** Registriert das HUD über dem Boss-Overlay (Standard-Slot der HudLib-Mods). */
    //? if >=1.21.11 {
    /*public static void register(RegisterGuiLayersEvent event, Identifier id, HudRenderer renderer) {
    *///?} else {
    public static void register(RegisterGuiLayersEvent event, ResourceLocation id, HudRenderer renderer) {
    //?}
        event.registerAbove(VanillaGuiLayers.BOSS_OVERLAY, id, renderer::render);
    }
}
