package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudAnchor;
import de.dennisthegamer.hudlib.position.HudPlacement;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Vollbild-Editor: die echte HUD-Beispiel-Box (geliefert vom konsumierenden Mod über
 * {@link HudBoxProvider}) wird an der aktuellen Arbeitskopie gezeichnet und kann mit der Maus
 * verschoben werden. Nicht pausierend, Welt bleibt sichtbar (renderBackground überschrieben).
 * Confirm reicht die Arbeitskopie an den Konsumenten weiter, Cancel verwirft.
 */
public class HudEditorScreen extends class_437 {

    private final class_437 parent;
    private final HudBoxProvider box;
    private final HudSlotStore store;
    private final Consumer<HudPlacement> onConfirm;
    private HudPlacement working;

    // Letzte gezeichnete Box (in skaliertem Raum) für Maus-Trefferprüfung.
    private float scale = 1.0f;
    private int scaledW, scaledH, boxX, boxY, boxW, boxH;
    private boolean dragging;
    private int grabDX, grabDY;

    public HudEditorScreen(class_437 parent, HudBoxProvider box, HudSlotStore store,
                            Supplier<HudPlacement> current, Consumer<HudPlacement> onConfirm) {
        super(class_2561.method_43471("hudlib.editor.title"));
        this.parent = parent;
        this.box = box;
        this.store = store;
        this.onConfirm = onConfirm;
        this.working = current.get();
    }

    public void applyWorking(HudPlacement placement) {
        this.working = placement;
    }

    public HudPlacement working() {
        return working;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int y = this.field_22790 - 52;
        method_37063(class_4185.method_46430(class_2561.method_43471("hudlib.editor.confirm"), b -> confirm())
                .method_46434(cx - 154, y, 150, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("hudlib.editor.presets"), b -> openPresets())
                .method_46434(cx + 4, y, 150, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), b -> method_25419())
                .method_46434(cx - 75, y + 24, 150, 20).method_46431());
    }

    private void confirm() {
        onConfirm.accept(working);
        class_310.method_1551().method_1507(parent);
    }

    private void openPresets() {
        class_310.method_1551().method_1507(new HudPresetScreen(this, box, store));
    }

    @Override
    public void method_25419() {
        // Cancel: nichts persistiert, einfach zurück.
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        this.scale = box.scale() <= 0 ? 1.0f : box.scale();
        this.boxW = box.width();
        this.boxH = box.height();
        this.scaledW = (int) (this.field_22789 / scale);
        this.scaledH = (int) (this.field_22790 / scale);
        this.boxX = working.resolveX(scaledW, boxW);
        this.boxY = working.resolveY(scaledH, boxH);

        box.drawSample(graphics, boxX, boxY, scale);

        // Dezenter Rahmen um die aktive Box (in Bildschirm-Pixeln).
        int px = (int) (boxX * scale), py = (int) (boxY * scale);
        int pw = (int) (boxW * scale), ph = (int) (boxH * scale);
        graphics.method_73198(px - 1, py - 1, pw + 2, ph + 2, 0xFFFFD700);

        graphics.method_27534(this.field_22793,
                class_2561.method_43471("hudlib.editor.hint"),
                this.field_22789 / 2, 24, 0xFFFFFFFF);
    }

    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // In-game: kein Abdunkeln, die laufende Welt bleibt sichtbar (wie im Referenz-Screenshot).
        // Ohne geladene Welt (vom Titelbildschirm aus geöffnet) gäbe das einen komplett schwarzen
        // Screen, daher dort den normalen Menü-Hintergrund (Panorama/Blur) zeichnen.
        if (class_310.method_1551().field_1687 == null) {
            super.method_25420(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --- Zieh-Logik, versionsunabhaengig -------------------------------------
    // Getrennt von den Overrides, weil deren Signatur sich ab 1.21.9 aendert. Die Logik
    // selbst ist ueber alle Baender identisch und darf nur EINMAL existieren.

    /** Startet das Ziehen, wenn der linke Knopf in die Box trifft. */
    private boolean beginDrag(double mouseX, double mouseY, int button) {
        if (button != 0) return false;
        int smx = (int) (mouseX / scale);
        int smy = (int) (mouseY / scale);
        if (smx >= boxX && smx <= boxX + boxW && smy >= boxY && smy <= boxY + boxH) {
            dragging = true;
            grabDX = smx - boxX;
            grabDY = smy - boxY;
            return true;
        }
        return false;
    }

    /** Zieht die Box mit und leitet den Anker aus der neuen Box-Mitte ab. */
    private boolean continueDrag(double mouseX, double mouseY, int button) {
        if (!dragging || button != 0) return false;
        int smx = (int) (mouseX / scale);
        int smy = (int) (mouseY / scale);
        int desiredX = smx - grabDX;
        int desiredY = smy - grabDY;
        int centerX = desiredX + boxW / 2;
        int centerY = desiredY + boxH / 2;
        HudAnchor anchor = HudAnchor.fromCenter(centerX, centerY, scaledW, scaledH);
        working = HudPlacement.fromAbsolute(anchor, desiredX, desiredY, scaledW, scaledH, boxW, boxH);
        return true;
    }

    /** Beendet das Ziehen. */
    private void endDrag(int button) {
        if (button == 0) dragging = false;
    }

    // Maus-API nimmt seit 1.21.9 ein MouseButtonEvent statt (x, y, button).
    //? if >=1.21.9 {
    @Override
    public boolean method_25402(net.minecraft.class_11909 event, boolean doubled) {
        if (super.method_25402(event, doubled)) {
            return true;
        }
        return beginDrag(event.comp_4798(), event.comp_4799(), event.method_74245());
    }

    @Override
    public boolean method_25403(net.minecraft.class_11909 event, double dragX, double dragY) {
        if (continueDrag(event.comp_4798(), event.comp_4799(), event.method_74245())) {
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25406(net.minecraft.class_11909 event) {
        endDrag(event.method_74245());
        return super.method_25406(event);
    }
    //?} else {
    /*@Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        return beginDrag(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (continueDrag(mouseX, mouseY, button)) {
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        endDrag(button);
        return super.mouseReleased(mouseX, mouseY, button);
    }
    *///?}
}
