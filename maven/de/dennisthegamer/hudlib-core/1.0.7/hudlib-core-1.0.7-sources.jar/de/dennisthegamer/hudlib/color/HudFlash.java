package de.dennisthegamer.hudlib.color;

/**
 * Abklingender Flash-Effekt-Timer (z. B. beim letzten Fang/Kill). Reine Zustandslogik,
 * keine Minecraft-Abhängigkeit — die Farbe/Alpha werden vom Renderer angewandt.
 */
public final class HudFlash {

    private final int durationTicks;
    private int color = HudColors.GOLD;
    private int ticksRemaining;

    public HudFlash(int durationTicks) {
        this.durationTicks = durationTicks;
    }

    /** Startet den Flash in der angegebenen RGB-Farbe. */
    public void trigger(int rgbColor) {
        this.color = rgbColor;
        this.ticksRemaining = durationTicks;
    }

    /** Einen Tick abziehen (im Client-Tick aufrufen). */
    public void tick() {
        if (ticksRemaining > 0) ticksRemaining--;
    }

    public boolean isActive() {
        return ticksRemaining > 0;
    }

    public int color() {
        return color;
    }

    /** 0..1-Anteil der Restdauer (für die Alpha-Berechnung im Renderer). */
    public float progress() {
        return durationTicks == 0 ? 0f : (float) ticksRemaining / durationTicks;
    }
}
