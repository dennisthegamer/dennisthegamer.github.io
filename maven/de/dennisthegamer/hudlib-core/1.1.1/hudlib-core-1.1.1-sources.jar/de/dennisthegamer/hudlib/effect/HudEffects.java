package de.dennisthegamer.hudlib.effect;

import de.dennisthegamer.hudlib.color.HudColors;
import de.dennisthegamer.hudlib.color.HudFlash;

/**
 * Bündelt die wiederkehrenden HUD-Effekt-Timer: Flash (delegiert an {@link HudFlash}) und
 * zeitbegrenzte Einblendung (z.B. "Reset"-Nachricht). Reine Zustandslogik ohne
 * Minecraft-Abhängigkeit; instanzbasiert, damit ein Mod mehrere HUDs mit eigenen
 * Effekten fahren kann. Ersetzt die statischen HudEffects-Kopien der 26.x-Mods.
 */
public final class HudEffects {

    private final HudFlash flash;
    private int messageTicksRemaining;

    public HudEffects(int flashDurationTicks) {
        this.flash = new HudFlash(flashDurationTicks);
    }

    /** Einen Tick weiterschalten (einmal pro Client-Tick aufrufen). */
    public void tick() {
        flash.tick();
        if (messageTicksRemaining > 0) messageTicksRemaining--;
    }

    /** Startet den Flash in Standard-Gold. */
    public void triggerFlash() {
        flash.trigger(HudColors.GOLD);
    }

    /** Startet den Flash in eigener RGB-Farbe. */
    public void triggerFlash(int rgbColor) {
        flash.trigger(rgbColor);
    }

    public boolean isFlashing() {
        return flash.isActive();
    }

    /** 0..1-Anteil der Flash-Restdauer (für die Alpha-Berechnung im Renderer). */
    public float flashAlpha() {
        return flash.progress();
    }

    /** RGB-Farbe des laufenden Flashs. */
    public int flashColor() {
        return flash.color();
    }

    /** Blendet eine Nachricht für die angegebene Tick-Dauer ein. */
    public void showMessage(int ticks) {
        this.messageTicksRemaining = ticks;
    }

    public boolean isMessageVisible() {
        return messageTicksRemaining > 0;
    }
}
