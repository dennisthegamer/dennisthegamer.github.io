package de.dennisthegamer.hudlib.color;

/** Reine ARGB-Mathe für HUD-Hintergründe/Akzente. Keine Minecraft-Abhängigkeit. */
public final class HudColors {

    /** Gold-Akzent, den mehrere Mods hartkodiert nutzen. */
    public static final int GOLD = 0xFFD700;

    private HudColors() {}

    /** Reiner Hintergrund-ARGB aus einer 0..1-Opacity (schwarzer BG): {@code (int)(opacity*255) << 24}. */
    public static int backgroundColor(float opacity) {
        int a = clampByte((int) (opacity * 255));
        return a << 24;
    }

    /** Setzt den Alpha-Kanal eines RGB(A)-Werts aus einer 0..1-Opacity. */
    public static int withOpacity(int rgb, float opacity) {
        int a = clampByte((int) (opacity * 255));
        return (a << 24) | (rgb & 0x00FFFFFF);
    }

    private static int clampByte(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}
