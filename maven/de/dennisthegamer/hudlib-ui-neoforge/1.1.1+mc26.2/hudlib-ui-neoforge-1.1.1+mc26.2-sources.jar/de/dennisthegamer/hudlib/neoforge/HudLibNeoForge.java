package de.dennisthegamer.hudlib.neoforge;

import de.dennisthegamer.hudlib.ui.HudRenderer;
import net.minecraft.resources.Identifier;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * NeoForge-Seite der HUD-Registrierung; aus dem RegisterGuiLayersEvent-Handler des
 * Konsumenten-Mod-Busses aufrufen (Gui-Layer sind pro Mod-Bus — deshalb reicht der
 * Konsument das Event herein, statt dass die Lib selbst lauscht).
 */
public final class HudLibNeoForge {

    private HudLibNeoForge() {
    }

    /** Registriert das HUD über dem Boss-Overlay (Standard-Slot der HudLib-Mods). */
    public static void register(RegisterGuiLayersEvent event, Identifier id, HudRenderer renderer) {
        event.registerAbove(VanillaGuiLayers.BOSS_OVERLAY, id, renderer::render);
    }
}
