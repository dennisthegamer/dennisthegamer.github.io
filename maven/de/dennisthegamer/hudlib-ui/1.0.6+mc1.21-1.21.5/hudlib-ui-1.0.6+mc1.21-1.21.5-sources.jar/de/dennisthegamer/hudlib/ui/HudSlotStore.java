package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudPreset;

import java.util.List;

/** Der Mod bildet die Slot-Liste auf seine eigene Config ab. */
public interface HudSlotStore {
    /** Mutierbare Liste des Mods (Slots werden direkt hinzugefügt/entfernt/ersetzt). */
    List<HudPreset> slots();

    /** Persistiert die Config des Mods. */
    void save();
}
