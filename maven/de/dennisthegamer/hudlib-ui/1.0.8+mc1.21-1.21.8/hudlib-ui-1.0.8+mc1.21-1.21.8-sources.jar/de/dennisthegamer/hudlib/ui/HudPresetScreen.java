package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudAnchor;
import de.dennisthegamer.hudlib.position.HudPlacement;
import de.dennisthegamer.hudlib.position.HudPreset;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Picker: oben feste Anker-Presets (9 Buttons), unten eigene Slots (Anwenden/Umbenennen/Löschen)
 * plus ein Namensfeld zum Speichern der aktuellen Position. Änderungen an Slots werden sofort
 * persistiert; die Auswahl eines Presets/Slots setzt die Arbeitskopie im Editor.
 */
public class HudPresetScreen extends class_437 {

    private final HudEditorScreen editor;
    private final HudBoxProvider box;
    private final HudSlotStore store;
    private class_342 nameField;
    /** >=0: Namensfeld benennt diesen Slot um; -1: „Speichern" legt neuen Slot an. */
    private int renameIndex = -1;

    public HudPresetScreen(HudEditorScreen editor, HudBoxProvider box, HudSlotStore store) {
        super(class_2561.method_43471("hudlib.preset.title"));
        this.editor = editor;
        this.box = box;
        this.store = store;
    }

    @Override
    protected void method_25426() {
        // Feste Anker-Presets: 3x3-Raster oben.
        int gridLeft = this.field_22789 / 2 - 154;
        int gridTop = 40;
        HudAnchor[] anchors = HudAnchor.values();
        for (int i = 0; i < anchors.length; i++) {
            HudAnchor anchor = anchors[i];
            int col = i % 3;
            int row = i / 3;
            method_37063(class_4185.method_46430(
                            class_2561.method_43471(anchor.translationKey()),
                            b -> editor.applyWorking(HudPlacement.of(anchor)))
                    .method_46434(gridLeft + col * 104, gridTop + row * 22, 100, 20)
                    .method_46431());
        }

        // Eigene Slots: je eine Zeile mit Anwenden / Umbenennen / Löschen.
        int slotTop = gridTop + 3 * 22 + 12;
        for (int i = 0; i < store.slots().size(); i++) {
            final int index = i;
            HudPreset slot = store.slots().get(i);
            int y = slotTop + i * 22;
            method_37063(class_4185.method_46430(
                            class_2561.method_43469("hudlib.preset.apply_named", slot.name()),
                            b -> editor.applyWorking(store.slots().get(index).placement()))
                    .method_46434(gridLeft, y, 160, 20).method_46431());
            method_37063(class_4185.method_46430(
                            class_2561.method_43471("hudlib.preset.rename"),
                            b -> beginRename(index))
                    .method_46434(gridLeft + 164, y, 70, 20).method_46431());
            method_37063(class_4185.method_46430(
                            class_2561.method_43471("hudlib.preset.delete"),
                            b -> {
                                store.slots().remove(index);
                                store.save();
                                rebuild();
                            })
                    .method_46434(gridLeft + 238, y, 70, 20).method_46431());
        }

        // Namensfeld + Speichern-Button + Zurück.
        int bottom = this.field_22790 - 52;
        this.nameField = new class_342(this.field_22793, gridLeft, bottom, 160, 20,
                class_2561.method_43471("hudlib.preset.name_hint"));
        this.nameField.method_47404(class_2561.method_43471("hudlib.preset.name_hint"));
        method_37063(this.nameField);
        method_37063(class_4185.method_46430(class_2561.method_43471("hudlib.preset.save"), b -> saveCurrent())
                .method_46434(gridLeft + 164, bottom, 144, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.back"), b -> class_310.method_1551().method_1507(editor))
                .method_46434(this.field_22789 / 2 - 75, this.field_22790 - 26, 150, 20).method_46431());
    }

    private void beginRename(int index) {
        this.renameIndex = index;
        this.nameField.method_1852(store.slots().get(index).name());
    }

    private void saveCurrent() {
        String name = nameField.method_1882().isBlank()
                ? ("Slot " + (store.slots().size() + 1))
                : nameField.method_1882().trim();
        if (renameIndex >= 0 && renameIndex < store.slots().size()) {
            // Umbenennen: Placement behalten, nur Namen ersetzen.
            HudPreset old = store.slots().get(renameIndex);
            store.slots().set(renameIndex, new HudPreset(name, old.placement()));
            renameIndex = -1;
        } else {
            // Neuer Slot mit aktueller Arbeitskopie aus dem Editor.
            store.slots().add(new HudPreset(name, editor.working()));
        }
        store.save();
        rebuild();
    }

    private void rebuild() {
        this.renameIndex = -1;
        this.method_37067();
        this.method_25426();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, 0xFFFFFFFF);
    }

    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Konsistent zum Editor: in-game bleibt die Welt sichtbar; ohne geladene Welt (Titelscreen)
        // den normalen Menü-Hintergrund zeichnen. Anschließend die HUD-Vorschau zeichnen - dies
        // läuft VOR dem Widget-Rendering von super.render(), also liegen die Picker-Buttons oben und
        // bleiben klickbar, während das HUD an seiner aktuellen Position sichtbar ist.
        if (class_310.method_1551().field_1687 == null) {
            super.method_25420(graphics, mouseX, mouseY, partialTick);
        }
        drawHudPreview(graphics);
    }

    /** Zeichnet die HUD-Beispiel-Box an der aktuellen Arbeitskopie des Editors (Live-Vorschau). */
    private void drawHudPreview(class_332 graphics) {
        float scale = box.scale() <= 0 ? 1.0f : box.scale();
        int boxW = box.width();
        int boxH = box.height();
        int scaledW = (int) (this.field_22789 / scale);
        int scaledH = (int) (this.field_22790 / scale);
        HudPlacement placement = editor.working();
        int x = placement.resolveX(scaledW, boxW);
        int y = placement.resolveY(scaledH, boxH);
        box.drawSample(graphics, x, y, scale);

        int px = (int) (x * scale), py = (int) (y * scale);
        int pw = (int) (boxW * scale), ph = (int) (boxH * scale);
        HudOutline.draw(graphics, px - 1, py - 1, pw + 2, ph + 2, 0xFFFFD700);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(editor);
    }
}
