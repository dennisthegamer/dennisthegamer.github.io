package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudPlacement;
import net.minecraft.class_332;

/**
 * Zeichnet eine HUD-Box an ihrem {@link HudPlacement}: skaliert (pose push/scale), malt den
 * Opacity-Hintergrund und ruft den Content-Zeichner mit dem Box-Ursprung auf. Ersetzt das in
 * den Konsumenten kopierte Ecken-/Margin-/Scale-Boilerplate; da das Placement durchgereicht
 * wird, ist jedes HudPanel-HUD automatisch frei positionierbar.
 */
public final class HudPanel {

    private HudPanel() {
    }

    @FunctionalInterface
    public interface HudContent {
        /** Zeichnet den Box-Inhalt; (x,y) ist die linke obere Box-Ecke im skalierten Raum. */
        void draw(class_332 graphics, int x, int y);
    }

    /** Löst das Placement im skalierten Bildschirmraum auf und zeichnet dort. */
    public static void draw(class_332 graphics, HudPlacement placement,
                            int boxWidth, int boxHeight, float scale, float bgOpacity,
                            HudContent content) {
        float s = scale <= 0 ? 1.0f : scale;
        int scaledW = (int) (graphics.method_51421() / s);
        int scaledH = (int) (graphics.method_51443() / s);
        int x = placement.resolveX(scaledW, boxWidth);
        int y = placement.resolveY(scaledH, boxHeight);
        drawAt(graphics, x, y, boxWidth, boxHeight, s, bgOpacity, content);
    }

    /** Zeichnet die Box an expliziten (skalierten) Koordinaten — für Editor-Vorschauen. */
    public static void drawAt(class_332 graphics, int x, int y,
                              int boxWidth, int boxHeight, float scale, float bgOpacity,
                              HudContent content) {
        float s = scale <= 0 ? 1.0f : scale;
        // GuiGraphics.pose() liefert seit 1.21.6 einen Matrix3x2fStack (2D: pushMatrix/
        // popMatrix, scale(x, y)) statt eines PoseStack (3D: pushPose/popPose, scale(x, y, z)).
        // Band A endet an 1.21.5 genau wegen dieser Grenze -- 1.21.6-1.21.8 laufen als eigene
        // Kapitel-Zielversion (1.21.8-Buchstabe), nicht als Laufzeit-Range von Band A.
        //? if >=1.21.6 {
        /*org.joml.Matrix3x2fStack pose = graphics.pose();
        pose.pushMatrix();
        *///?} else {
        net.minecraft.class_4587 pose = graphics.method_51448();
        pose.method_22903();
        //?}
        // finally: eine Exception im Konsumenten-Zeichner darf den pose-Stack des Frames
        // nicht unbalanciert zurücklassen.
        try {
            //? if >=1.21.6 {
            /*pose.scale(s, s);
            *///?} else {
            pose.method_22905(s, s, 1.0f);
            //?}
            if (bgOpacity > 0) {
                int bgColor = (int) (Math.min(bgOpacity, 1.0f) * 255) << 24;
                graphics.method_25294(x, y, x + boxWidth, y + boxHeight, bgColor);
            }
            content.draw(graphics, x, y);
        } finally {
            //? if >=1.21.6 {
            /*pose.popMatrix();
            *///?} else {
            pose.method_22909();
            //?}
        }
    }
}
