package de.dennisthegamer.hudlib.fabric;

import de.dennisthegamer.hudlib.ui.HudRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;

/**
 * Fabric-Seite der HUD-Registrierung; aus dem ClientModInitializer des Konsumenten aufrufen.
 * Bewusst dünn: der Wert ist die einheitliche {@link HudRenderer}-Signatur über beide Loader.
 */
public final class HudLibFabric {

    private HudLibFabric() {
    }

    /** Hängt das HUD-Element hinter die Bossbar (Standard-Slot der HudLib-Mods). */
    public static void register(Identifier id, HudRenderer renderer) {
        HudElementRegistry.attachElementAfter(VanillaHudElements.BOSS_BAR, id, renderer::render);
    }
}
