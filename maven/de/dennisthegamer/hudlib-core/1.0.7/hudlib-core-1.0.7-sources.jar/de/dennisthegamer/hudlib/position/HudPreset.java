package de.dennisthegamer.hudlib.position;

/** Benannter, gespeicherter Positions-Slot. */
public record HudPreset(String name, HudPlacement placement) {
}
