package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/**
 * Einziger Ort für den Screen-Wechsel: Minecraft.setScreen ist auf 26.2 nach
 * Gui.setScreen umgezogen; auf 26.1 existiert Gui.setScreen noch nicht.
 */
final class HudNav {

    private HudNav() {
    }

    static void setScreen(Screen screen) {
        //? if >=26.2 {
        /*Minecraft.getInstance().gui.setScreen(screen);
        *///?} else {
        Minecraft.getInstance().setScreen(screen);
        //?}
    }
}
