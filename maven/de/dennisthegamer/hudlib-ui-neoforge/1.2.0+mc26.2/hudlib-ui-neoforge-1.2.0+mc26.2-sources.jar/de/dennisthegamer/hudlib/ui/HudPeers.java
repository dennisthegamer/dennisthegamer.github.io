package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudPlacement;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.List;

/**
 * Zeichnet die Kontext-Elemente eines Editors: jedes an seiner echten Position, danach
 * halbtransparent abgedunkelt und grau umrandet. Sie sollen die Lage zeigen, aber nicht mit
 * der Box konkurrieren, die gerade bearbeitet wird.
 */
final class HudPeers {

    /** Abdunklung über dem Kontext-Element. */
    private static final int DIM = 0x99000000;
    /** Rahmenfarbe des Kontext-Elements; das aktive Element trägt Gold. */
    private static final int OUTLINE = 0xFF808080;

    private HudPeers() {
    }

    static void drawAll(GuiGraphicsExtractor graphics, List<HudPeer> peers,
                        int screenW, int screenH) {
        for (HudPeer peer : peers) {
            HudPlacement placement = peer.placement().get();
            // Ein Konsument kann ein noch nicht migriertes (null) Placement liefern -- das
            // ist kein Grund, den Editor abstürzen zu lassen.
            if (placement == null || placement.anchor() == null) {
                continue;
            }
            float scale = peer.box().scale() <= 0 ? 1.0f : peer.box().scale();
            int w = peer.box().width();
            int h = peer.box().height();
            int x = placement.resolveX((int) (screenW / scale), w);
            int y = placement.resolveY((int) (screenH / scale), h);
            peer.box().drawSample(graphics, x, y, scale, placement.anchor());

            int px = (int) (x * scale), py = (int) (y * scale);
            int pw = (int) (w * scale), ph = (int) (h * scale);
            graphics.fill(px, py, px + pw, py + ph, DIM);
            HudOutline.draw(graphics, px - 1, py - 1, pw + 2, ph + 2, OUTLINE);
        }
    }
}
