package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Zeichnet einen 1px-Rahmen aus vier fill()-Aufrufen — bewusst statt GuiGraphics.renderOutline.
 *
 * <p>Grund: renderOutline heisst in Mojmap auf 1.21.9/1.21.10 "submitOutline" und erst ab 1.21.11
 * wieder "renderOutline". Das NeoForge-Artefakt laeuft gegen die Mojmap-Namen der Laufzeitversion,
 * also kann EIN Artefakt fuer 1.21.9-1.21.11 diese Methode nicht aufrufen — es starb dort mit
 * NoSuchMethodError, sobald der Editor seinen Rahmen zeichnete. fill (intermediary method_25294)
 * heisst dagegen von 1.21 bis 1.21.11 durchgehend "fill"; gegen die Loom-Mappings aller sechs
 * Versionen geprueft. Das Fabric-Artefakt war nie betroffen (intermediary ist stabil).
 *
 * <p>Die Geometrie ist die von vanilla renderOutline: oben und unten voll, links und rechts um 1px
 * eingerueckt, damit die Ecken nicht doppelt gezeichnet werden.
 */
final class HudOutline {

    private HudOutline() {
    }

    static void draw(GuiGraphics graphics, int x, int y, int width, int height, int color) {
        graphics.fill(x, y, x + width, y + 1, color);
        graphics.fill(x, y + height - 1, x + width, y + height, color);
        graphics.fill(x, y + 1, x + 1, y + height - 1, color);
        graphics.fill(x + width - 1, y + 1, x + width, y + height - 1, color);
    }
}
