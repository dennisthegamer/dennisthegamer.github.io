package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Einheitliche HUD-Render-Signatur über beide Loader (entspricht Fabrics HudElement-SAM
 * auf 26.x). Fabric registriert sie über HudLibFabric, NeoForge über HudLibNeoForge.
 */
@FunctionalInterface
public interface HudRenderer {
    void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker);
}
