package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudAnchor;
import de.dennisthegamer.hudlib.position.HudPlacement;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Vollbild-Editor: die echte HUD-Beispiel-Box (geliefert vom konsumierenden Mod über
 * {@link HudBoxProvider}) wird an der aktuellen Arbeitskopie gezeichnet und kann mit der Maus
 * verschoben werden. Nicht pausierend, Welt bleibt sichtbar (extractBackground überschrieben —
 * der 26.x-Nachfolger von renderBackground, wird vom Screen-Wrapper VOR extractRenderState
 * aufgerufen). Confirm reicht die Arbeitskopie an den Konsumenten weiter, Cancel verwirft.
 */
public class HudEditorScreen extends Screen {

    private final Screen parent;
    private final HudBoxProvider box;
    private final HudSlotStore store;
    private final Consumer<HudPlacement> onConfirm;
    private HudPlacement working;
    private final List<HudPeer> peers;
    private final Component elementLabel;

    // Letzte gezeichnete Box (in skaliertem Raum) für Maus-Trefferprüfung.
    private float scale = 1.0f;
    private int scaledW, scaledH, boxX, boxY, boxW, boxH;
    private boolean dragging;
    private int grabDX, grabDY;

    public HudEditorScreen(Screen parent, HudBoxProvider box, HudSlotStore store,
                            Supplier<HudPlacement> current, Consumer<HudPlacement> onConfirm) {
        this(parent, box, store, current, onConfirm, List.of(), null);
    }

    public HudEditorScreen(Screen parent, HudBoxProvider box, HudSlotStore store,
                            Supplier<HudPlacement> current, Consumer<HudPlacement> onConfirm,
                            List<HudPeer> peers, Component elementLabel) {
        super(elementLabel == null
                ? Component.translatable("hudlib.editor.title")
                : Component.translatable("hudlib.editor.title_for", elementLabel));
        this.parent = parent;
        this.box = box;
        this.store = store;
        this.onConfirm = onConfirm;
        this.working = current.get();
        this.peers = List.copyOf(peers);
        this.elementLabel = elementLabel;
    }

    /** Kontext-Elemente, die der Preset-Screen ebenfalls zeichnet. */
    public List<HudPeer> peers() {
        return peers;
    }

    public void applyWorking(HudPlacement placement) {
        this.working = placement;
    }

    public HudPlacement working() {
        return working;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 52;
        addRenderableWidget(Button.builder(Component.translatable("hudlib.editor.confirm"), b -> confirm())
                .bounds(cx - 154, y, 150, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("hudlib.editor.presets"), b -> openPresets())
                .bounds(cx + 4, y, 150, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.cancel"), b -> onClose())
                .bounds(cx - 75, y + 24, 150, 20).build());
    }

    private void confirm() {
        onConfirm.accept(working);
        HudNav.setScreen(parent);
    }

    private void openPresets() {
        HudNav.setScreen(new HudPresetScreen(this, box, store));
    }

    @Override
    public void onClose() {
        // Cancel: nichts persistiert, einfach zurück.
        HudNav.setScreen(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        this.scale = box.scale() <= 0 ? 1.0f : box.scale();
        this.boxW = box.width();
        this.boxH = box.height();
        this.scaledW = (int) (this.width / scale);
        this.scaledH = (int) (this.height / scale);
        this.boxX = working.resolveX(scaledW, boxW);
        this.boxY = working.resolveY(scaledH, boxH);

        HudPeers.drawAll(graphics, peers, this.width, this.height);

        box.drawSample(graphics, boxX, boxY, scale, working.anchor());

        // Dezenter Rahmen um die aktive Box (in Bildschirm-Pixeln).
        int px = (int) (boxX * scale), py = (int) (boxY * scale);
        int pw = (int) (boxW * scale), ph = (int) (boxH * scale);
        HudOutline.draw(graphics, px - 1, py - 1, pw + 2, ph + 2, 0xFFFFD700);

        graphics.centeredText(this.font, this.title, this.width / 2, 16, 0xFFFFFFFF);

        graphics.centeredText(this.font,
                Component.translatable("hudlib.editor.hint"),
                this.width / 2, 32, 0xFFFFFFFF);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // In-game: kein Abdunkeln, die laufende Welt bleibt sichtbar. Ohne geladene Welt
        // (vom Titelbildschirm aus geöffnet) den normalen Menü-Hintergrund zeichnen lassen.
        if (Minecraft.getInstance().level == null) {
            super.extractBackground(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // --- Zieh-Logik, MC-frei — identisch zu Band A/B, existiert genau einmal ------------

    /** Startet das Ziehen, wenn der linke Knopf in die Box trifft. */
    private boolean beginDrag(double mouseX, double mouseY, int button) {
        if (button != InputConstants.MOUSE_BUTTON_LEFT) return false;
        int smx = (int) (mouseX / scale);
        int smy = (int) (mouseY / scale);
        if (smx >= boxX && smx <= boxX + boxW && smy >= boxY && smy <= boxY + boxH) {
            dragging = true;
            grabDX = smx - boxX;
            grabDY = smy - boxY;
            return true;
        }
        return false;
    }

    /** Zieht die Box mit und leitet den Anker aus der neuen Box-Mitte ab. */
    private boolean continueDrag(double mouseX, double mouseY, int button) {
        if (!dragging || button != InputConstants.MOUSE_BUTTON_LEFT) return false;
        int smx = (int) (mouseX / scale);
        int smy = (int) (mouseY / scale);
        int desiredX = smx - grabDX;
        int desiredY = smy - grabDY;
        int centerX = desiredX + boxW / 2;
        int centerY = desiredY + boxH / 2;
        HudAnchor anchor = HudAnchor.fromCenter(centerX, centerY, scaledW, scaledH);
        working = HudPlacement.fromAbsolute(anchor, desiredX, desiredY, scaledW, scaledH, boxW, boxH);
        return true;
    }

    /** Beendet das Ziehen. */
    private void endDrag(int button) {
        if (button == InputConstants.MOUSE_BUTTON_LEFT) dragging = false;
    }

    // 26.1 bis 26.3 nutzen alle die MouseButtonEvent-API — kein Schalter nötig. Die
    // Tastennummern aber NIE als Literal: 26.3 (SDL) zählt links als 1 statt 0. Die
    // InputConstants-Konstante wird pro Target eingesetzt und stimmt dadurch überall.
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubled) {
        if (super.mouseClicked(event, doubled)) {
            return true;
        }
        return beginDrag(event.x(), event.y(), event.button());
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (continueDrag(event.x(), event.y(), event.button())) {
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        endDrag(event.button());
        return super.mouseReleased(event);
    }
}
