package de.dennisthegamer.hudlib.position;

/**
 * Einmalige Migration der alten 4-Ecken-Enum-Position (String) auf das freie
 * {@link HudPlacement}. Der 10px-Rand entspricht dem bisherigen {@code MARGIN} im HUD-Renderer.
 */
public final class HudPositionMigration {

    /** Derselbe Rand, den {@link HudPlacement#of(HudAnchor)} für randnahe Anker lässt. */
    public static final int LEGACY_MARGIN = HudPlacement.DEFAULT_MARGIN;

    private HudPositionMigration() {
    }

    public static HudPlacement fromLegacy(String legacy) {
        if (legacy == null) {
            return HudPlacement.of(HudAnchor.TOP_LEFT);
        }
        return switch (legacy) {
            case "TOP_RIGHT" -> HudPlacement.of(HudAnchor.TOP_RIGHT);
            case "BOTTOM_LEFT" -> HudPlacement.of(HudAnchor.BOTTOM_LEFT);
            case "BOTTOM_RIGHT" -> HudPlacement.of(HudAnchor.BOTTOM_RIGHT);
            default -> HudPlacement.of(HudAnchor.TOP_LEFT);
        };
    }

    /** Alias für Konsumenten: mappt einen Legacy-4-Ecken-String auf ein Placement. */
    public static HudPlacement fromLegacyCorner(String legacyCorner) {
        return fromLegacy(legacyCorner);
    }

    /**
     * Migration einer NEUN-Werte-Anker-Enum (als String) auf ein {@link HudPlacement}.
     * Bewusst getrennt von {@link #fromLegacy(String)}: das kennt nur die vier Ecken und
     * schickt alles andere nach TOP_LEFT -- für eine Neun-Werte-Quelle wäre das ein
     * stiller Positionssprung für jeden, der einen mittigen Anker gewählt hatte.
     *
     * @param legacy   Name des Alt-Wertes; {@code CENTER} wird als {@code MIDDLE_CENTER} gelesen
     * @param fallback Anker für null/unbekannt
     * @param margin   Randabstand; für eine Quelle mit eigenem Rand deren Wert übergeben,
     *                 sonst springt das HUD bei der Migration
     */
    public static HudPlacement fromLegacyAnchor(String legacy, HudAnchor fallback, int margin) {
        if (legacy == null) {
            return HudPlacement.of(fallback, margin);
        }
        String name = "CENTER".equals(legacy) ? "MIDDLE_CENTER" : legacy;
        for (HudAnchor anchor : HudAnchor.values()) {
            if (anchor.name().equals(name)) {
                return HudPlacement.of(anchor, margin);
            }
        }
        return HudPlacement.of(fallback, margin);
    }
}
