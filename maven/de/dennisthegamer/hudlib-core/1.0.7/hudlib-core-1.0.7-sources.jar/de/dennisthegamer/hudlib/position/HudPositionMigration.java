package de.dennisthegamer.hudlib.position;

/**
 * Einmalige Migration der alten 4-Ecken-Enum-Position (String) auf das freie
 * {@link HudPlacement}. Der 10px-Rand entspricht dem bisherigen {@code MARGIN} im HUD-Renderer.
 */
public final class HudPositionMigration {

    /** Derselbe Rand, den {@link HudPlacement#of(HudAnchor)} für randnahe Anker lässt. */
    public static final int LEGACY_MARGIN = HudPlacement.DEFAULT_MARGIN;

    private HudPositionMigration() {
    }

    public static HudPlacement fromLegacy(String legacy) {
        if (legacy == null) {
            return HudPlacement.of(HudAnchor.TOP_LEFT);
        }
        return switch (legacy) {
            case "TOP_RIGHT" -> HudPlacement.of(HudAnchor.TOP_RIGHT);
            case "BOTTOM_LEFT" -> HudPlacement.of(HudAnchor.BOTTOM_LEFT);
            case "BOTTOM_RIGHT" -> HudPlacement.of(HudAnchor.BOTTOM_RIGHT);
            default -> HudPlacement.of(HudAnchor.TOP_LEFT);
        };
    }

    /** Alias für Konsumenten: mappt einen Legacy-4-Ecken-String auf ein Placement. */
    public static HudPlacement fromLegacyCorner(String legacyCorner) {
        return fromLegacy(legacyCorner);
    }
}
