package de.dennisthegamer.hudlib.position;

/**
 * Geometrie eines Blocks aus mehreren Textzeilen mit je eigenem Hintergrund (Richtungspfeil-
 * Liste). Die vermessene Box ist die GEZEICHNETE Ausdehnung inklusive der Zeilen-Hintergründe,
 * denn genau daran löst {@link HudPlacement} auf und genau die umrahmt der Editor.
 * Reine Mathematik, keine Minecraft-Abhängigkeit -> headless testbar.
 */
public final class HudTextLayout {

    /** Rand zwischen Text und Zeilen-Hintergrund, auf jeder Seite. */
    public static final int PADDING = 2;
    /** Lücke zwischen zwei Zeilen-Hintergründen. */
    public static final int LINE_SPACING = 3;

    private HudTextLayout() {
    }

    /** Abstand zwischen zwei Zeilen-Oberkanten. */
    public static int lineStep(int fontLineHeight) {
        return fontLineHeight + PADDING * 2 + LINE_SPACING;
    }

    public static int boxWidth(int[] lineWidths) {
        if (lineWidths.length == 0) {
            return 0;
        }
        int max = 0;
        for (int w : lineWidths) {
            max = Math.max(max, w);
        }
        return max + PADDING * 2;
    }

    /** Die letzte Zeile trägt kein {@link #LINE_SPACING} mehr, sonst hinge unten Luft an der Box. */
    public static int boxHeight(int lineCount, int fontLineHeight) {
        return lineCount <= 0 ? 0 : lineCount * lineStep(fontLineHeight) - LINE_SPACING;
    }

    /**
     * X des Zeilen-TEXTES relativ zur linken Box-Kante. Die Ausrichtung folgt der Spalte des
     * Ankers, damit die angeheftete Kante stehen bleibt, wenn sich die Zeilenbreite ändert
     * (z. B. "100m" -> "99m").
     */
    public static int lineX(HudAnchor anchor, int boxWidth, int lineWidth) {
        return switch (anchor.horizontalIndex()) {
            case 0 -> PADDING;
            case 1 -> (boxWidth - lineWidth) / 2;
            default -> boxWidth - lineWidth - PADDING;
        };
    }
}
