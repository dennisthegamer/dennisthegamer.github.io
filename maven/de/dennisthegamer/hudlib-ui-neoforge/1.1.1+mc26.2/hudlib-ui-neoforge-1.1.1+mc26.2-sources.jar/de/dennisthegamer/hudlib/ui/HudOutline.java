package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Zeichnet einen 1px-Rahmen aus vier fill()-Aufrufen. Auf 26.x gäbe es zwar wieder ein
 * vanilla outline(), aber fill() ist über alle von HudLib getragenen Versionen identisch
 * und die Geometrie bleibt so deckungsgleich mit Band A/B: oben und unten voll, links und
 * rechts um 1px eingerückt, damit die Ecken nicht doppelt gezeichnet werden.
 */
final class HudOutline {

    private HudOutline() {
    }

    static void draw(GuiGraphicsExtractor graphics, int x, int y, int width, int height, int color) {
        graphics.fill(x, y, x + width, y + 1, color);
        graphics.fill(x, y + height - 1, x + width, y + height, color);
        graphics.fill(x, y + 1, x + 1, y + height - 1, color);
        graphics.fill(x + width - 1, y + 1, x + width, y + height - 1, color);
    }
}
