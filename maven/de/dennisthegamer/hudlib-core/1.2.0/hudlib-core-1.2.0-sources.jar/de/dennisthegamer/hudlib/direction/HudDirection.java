package de.dennisthegamer.hudlib.direction;

/**
 * Peilung eines Weltziels relativ zur Blickrichtung des Spielers, als 45-Grad-Sektor.
 * Reine Mathematik ohne Minecraft-Abhängigkeit -> headless testbar.
 */
public final class HudDirection {

    /** Sektor 0 = geradeaus, im Uhrzeigersinn in 45-Grad-Schritten. */
    private static final String[] GLYPHS = {"↑", "↗", "→", "↘",
                                            "↓", "↙", "←", "↖"};

    /**
     * Winkeltoleranz für Grenzfälle bei Sektorgrenzen (in Grad, nicht Radians).
     * Ändert nichts an echten Gleichständen — {@code Math.round} rundet in Java auf beiden
     * Seiten der Null zur positiven Unendlichkeit ({@code round(-0.5) == 0}), das Epsilon
     * greift also nur bei Gleitkomma-Beinahe-Treffern, nie bei exakten .5-Werten. Bitte nicht
     * versucht sein, die Rundung selbst "reparieren" zu wollen.
     */
    private static final double SECTOR_EPSILON = 1e-9;

    private HudDirection() {
    }

    /**
     * Sektor 0..7 des Ziels relativ zur Blickrichtung.
     *
     * @param dx        Ziel-X minus Spieler-X
     * @param dz        Ziel-Z minus Spieler-Z
     * @param playerYaw Yaw des Spielers in Grad (MC: 0 = +Z, 90 = -X)
     */
    public static int sector(double dx, double dz, float playerYaw) {
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double relative = wrapDegrees(targetYaw - playerYaw);
        // Epsilon vermeidet Gleitkommagenauigkeit-Probleme bei Sektorgrenzen.
        return Math.floorMod((int) Math.round((relative + SECTOR_EPSILON) / 45.0), 8);
    }

    /**
     * Glyphe (Pfeil-Symbol) für den angegebenen Sektor.
     *
     * @param sector Sektor 0..7 (wird mit floorMod auf Bereich normiert)
     * @return Pfeil-Zeichen (↑ ↗ → ↘ ↓ ↙ ← ↖)
     */
    public static String glyph(int sector) {
        return GLYPHS[Math.floorMod(sector, 8)];
    }

    /**
     * Normiert einen Winkel auf [-180, 180). Entspricht Minecrafts {@code Mth.wrapDegrees},
     * hier nachgebaut, damit core ohne Minecraft auskommt.
     */
    private static double wrapDegrees(double degrees) {
        double d = degrees % 360.0;
        if (d >= 180.0) {
            d -= 360.0;
        }
        if (d < -180.0) {
            d += 360.0;
        }
        return d;
    }
}
