package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudPlacement;

import java.util.function.Supplier;

/**
 * Ein weiteres HUD-Element desselben Mods, das im Editor nur als Kontext gezeichnet wird:
 * sichtbar, aber nicht anfassbar. Ohne das positioniert man zwei Elemente blind
 * übereinander.
 */
public record HudPeer(HudBoxProvider box, Supplier<HudPlacement> placement) {
}
