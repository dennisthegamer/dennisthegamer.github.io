package de.dennisthegamer.hudlib.ui;

import de.dennisthegamer.hudlib.position.HudAnchor;
import de.dennisthegamer.hudlib.position.HudPlacement;
import de.dennisthegamer.hudlib.position.HudTextLayout;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/**
 * Zeichnet einen Block aus mehreren Textzeilen mit je eigenem Hintergrund an seinem
 * {@link HudPlacement} -- das Gegenstück zu {@link HudPanel} für Inhalte, deren Zeilenzahl
 * und -breite sich zur Laufzeit ändern (Richtungspfeil-Listen).
 *
 * Die Zeilen richten sich nach der Spalte des Ankers aus. Dadurch bleibt die angeheftete
 * Kante stehen, wenn sich die Breite ändert: bei RIGHT ist resolveX + boxW == screenW +
 * offsetX, bei CENTER liegt die Box-Mitte auf screenW/2 + offsetX -- beides unabhängig von
 * der Box-Breite.
 */
public final class HudTextList {

    private HudTextList() {
    }

    /** Box {Breite, Höhe} des gezeichneten Blocks, Zeilen-Hintergründe eingerechnet. */
    public static int[] measure(List<String> lines, Font font) {
        if (lines.isEmpty()) {
            return new int[] {0, 0};
        }
        int[] widths = new int[lines.size()];
        for (int i = 0; i < lines.size(); i++) {
            widths[i] = font.width(lines.get(i));
        }
        return new int[] {
                HudTextLayout.boxWidth(widths),
                HudTextLayout.boxHeight(lines.size(), font.lineHeight)
        };
    }

    /** Löst das Placement im skalierten Bildschirmraum auf und zeichnet dort. */
    public static void draw(GuiGraphics graphics, HudPlacement placement,
                            List<String> lines, Font font, float scale,
                            int textColor, int backgroundColor) {
        if (lines.isEmpty()) {
            return;
        }
        float s = scale <= 0 ? 1.0f : scale;
        int[] box = measure(lines, font);
        int scaledW = (int) (graphics.guiWidth() / s);
        int scaledH = (int) (graphics.guiHeight() / s);
        int x = placement.resolveX(scaledW, box[0]);
        int y = placement.resolveY(scaledH, box[1]);
        drawAt(graphics, x, y, lines, font, s, placement.anchor(), textColor, backgroundColor);
    }

    /** Zeichnet den Block an expliziten (skalierten) Koordinaten -- für Editor-Vorschauen. */
    public static void drawAt(GuiGraphics graphics, int x, int y,
                              List<String> lines, Font font, float scale, HudAnchor anchor,
                              int textColor, int backgroundColor) {
        if (lines.isEmpty()) {
            return;
        }
        float s = scale <= 0 ? 1.0f : scale;
        int boxWidth = measure(lines, font)[0];
        int lineStep = HudTextLayout.lineStep(font.lineHeight);
        // GuiGraphics.pose() liefert seit 1.21.6 einen Matrix3x2fStack (2D: pushMatrix/
        // popMatrix, scale(x, y)) statt eines PoseStack (3D: pushPose/popPose, scale(x, y, z)).
        // Band A endet an 1.21.5 genau wegen dieser Grenze -- 1.21.6-1.21.8 laufen als eigene
        // Kapitel-Zielversion (1.21.8-Buchstabe), nicht als Laufzeit-Range von Band A.
        //? if >=1.21.6 {
        org.joml.Matrix3x2fStack pose = graphics.pose();
        pose.pushMatrix();
        //?} else {
        /*com.mojang.blaze3d.vertex.PoseStack pose = graphics.pose();
        pose.pushPose();
        *///?}
        // finally: eine Exception im Zeichnen darf den pose-Stack des Frames nicht
        // unbalanciert zurücklassen (wie in HudPanel).
        try {
            //? if >=1.21.6 {
            pose.scale(s, s);
            //?} else {
            /*pose.scale(s, s, 1.0f);
            *///?}
            int lineY = y;
            for (String line : lines) {
                int lineWidth = font.width(line);
                int lineX = x + HudTextLayout.lineX(anchor, boxWidth, lineWidth);
                graphics.fill(lineX - HudTextLayout.PADDING, lineY,
                        lineX + lineWidth + HudTextLayout.PADDING,
                        lineY + font.lineHeight + HudTextLayout.PADDING * 2,
                        backgroundColor);
                graphics.drawString(font, line, lineX, lineY + HudTextLayout.PADDING, textColor, true);
                lineY += lineStep;
            }
        } finally {
            //? if >=1.21.6 {
            pose.popMatrix();
            //?} else {
            /*pose.popPose();
            *///?}
        }
    }
}
