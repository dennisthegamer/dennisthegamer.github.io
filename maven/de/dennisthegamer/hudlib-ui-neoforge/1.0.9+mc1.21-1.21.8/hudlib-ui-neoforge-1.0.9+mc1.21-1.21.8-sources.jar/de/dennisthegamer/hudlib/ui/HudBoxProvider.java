package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.gui.GuiGraphics;

/** Der konsumierende Mod liefert Größe, Scale und Sample-Zeichnung seiner eigenen HUD-Box. */
public interface HudBoxProvider {
    int width();
    int height();

    /** Konsumenten-HUD-Scale (z.B. hudScale); 1.0f, falls der Mod keine eigene Skalierung hat. */
    float scale();

    /** Zeichnet die Beispiel-Box; der Konsument handhabt sein eigenes Scale-Push/Pop. */
    void drawSample(GuiGraphics graphics, int x, int y, float scale);
}
