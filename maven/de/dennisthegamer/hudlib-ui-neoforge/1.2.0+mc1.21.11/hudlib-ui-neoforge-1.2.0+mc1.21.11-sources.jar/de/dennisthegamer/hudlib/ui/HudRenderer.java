package de.dennisthegamer.hudlib.ui;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Einheitliche HUD-Render-Signatur über beide Loader. Fabric registriert sie über
 * HudLibFabric, NeoForge über HudLibNeoForge.
 *
 * <p>Die Signatur ist absichtlich deckungsgleich mit NeoForges Layer-SAM über alle vier
 * Bänder — LayeredDraw.Layer bis 1.21.5, GuiLayer ab 1.21.6 (per javap auf den
 * NeoForge-Universal-Jars: 21.5.97 nimmt LayeredDraw$Layer, 21.6.20-beta/21.7.25-beta/
 * 21.8.53/21.10.64/21.11.42 nehmen GuiLayer) — und mit Fabrics HudRenderCallback. Beide
 * deklarieren render(GuiGraphics, DeltaTracker), deshalb genügt überall eine
 * Methodenreferenz.</p>
 */
@FunctionalInterface
public interface HudRenderer {
    void render(GuiGraphics graphics, DeltaTracker deltaTracker);
}
